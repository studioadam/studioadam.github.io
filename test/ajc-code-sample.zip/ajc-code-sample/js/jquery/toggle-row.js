/*!
 * Expand/Collapse panels
 *
 */
 $(document).ready(function(){
	//row-info click
	
	$('.row-info').click(function() {
		if ($(this).next(".row-details").is(":hidden")) {
			$(this).next(".row-details").slideDown("fast");
			$(this).removeClass("closed").addClass("open");
			$(this).find('.row-toggle-image').attr('src','images/icons/toggle-open.png');
		} else {
			$(this).next(".row-details").slideUp("fast");
			$(this).addClass("closed").removeClass("open");
			$(this).find('.row-toggle-image').attr('src','images/icons/toggle-closed.png');
		}
	});
	

	//expand all click
	$("#expand-all").click(function() {
		$(".row-details").slideDown("fast");
		$(".row-info").removeClass("closed").addClass("open");
		$(".row-info").find('.row-toggle-image').attr('src','images/icons/toggle-open.png');
		return false;
	});
	
	//collapse all click
	$("#collapse-all").click(function() {
		$(".row-details").slideUp("fast");
		$(".row-info").removeClass("open").addClass("closed");
		$(".row-info").find('.row-toggle-image').attr('src','images/icons/toggle-closed.png');
		return false;
	});
	
});
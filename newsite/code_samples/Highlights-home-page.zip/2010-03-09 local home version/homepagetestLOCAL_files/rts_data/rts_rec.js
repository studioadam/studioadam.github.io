/* Copyright 2003-2006,SoDoIt,LLC */ 
